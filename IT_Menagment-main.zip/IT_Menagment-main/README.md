# IT_Menagment
<p>Vježbe ArchiMate</p>
<p>ArchiMate® 3.2 Specification</p>
<p>https://pubs.opengroup.org/architecture/archimate3-doc/ch-Relationships-Between-Core-Layers.html</p>
